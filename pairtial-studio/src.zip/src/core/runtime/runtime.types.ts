import type {
    Envelope
} from "../envelope/envelope.types"

import type {
    NodeExecutionState
} from "../types/types"



export type RuntimeEvent =
    | { type: "node.skipped"; runId: string; nodeId: string; timestamp: number; reason: string }
    | { type: "edge.routed"; runId: string; nodeId: string; edgeId: string; timestamp: number; active: boolean }
    | {
        type: "run.started"
        runId: string
        timestamp: number
    }
    | {
        type: "node.started"
        runId: string
        nodeId: string
        timestamp: number
    }
    | {
        type: "node.completed"
        runId: string
        nodeId: string
        timestamp: number
        envelope: Envelope
    }
    | {
        type: "node.failed"
        runId: string
        nodeId: string
        timestamp: number
        error: string
    }
    | {
        type: "envelope.created"
        runId: string
        nodeId: string
        timestamp: number
        envelope: Envelope
    }
    | {
        type: "run.completed"
        runId: string
        timestamp: number
    }| {
    type: "run.cancelled"
    runId: string
    timestamp: number
}
    | {
        type: "run.failed"
        runId: string
        timestamp: number
        error: string
    }
    
| {
    type: "envelope.received"
    runId: string
    nodeId: string
    timestamp: number
    envelope: Envelope
}



export type NodeExecutionStates =
    Record<string, NodeExecutionState>


export type RuntimeResult = {
    runId: string

    success: boolean

    envelopes: Envelope[]

    events: RuntimeEvent[]

    nodeStates: NodeExecutionStates
}

export type RuntimeEventListener = (
    event: RuntimeEvent
) => void


export type RuntimeOptions = {
    onEvent?: RuntimeEventListener
    signal?: AbortSignal
    maxConcurrency?: number
}